import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FloorComponent } from './floor.component';
import { SharedModule } from  '../../shared/shared.module';

import { routing } from './floor.route';
import { SeatComponent } from './seat/seat.component';
import { PlanAComponent } from './plan/plan-a.component';
import { PlanBComponent } from './plan/plan-b.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { SearchComponent } from './search.component';
import { CheckinComponent } from './checkin/checkin.component';
import { CheckoutComponent } from './checkout/checkout.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    routing
  ],
  declarations: [FloorComponent, SeatComponent, PlanAComponent, PlanBComponent, UserdetailsComponent, SearchComponent, CheckinComponent, CheckoutComponent]
})
export class FloorModule { }
