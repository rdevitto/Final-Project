import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";
import { User } from '../../model/user';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})

export class SearchComponent extends BaseComponent implements OnInit {

  public userId: string;
  public user: User;
  public hideError: Boolean;
  public userFound: Boolean;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
      super(stateRepresentationRendererService);
      
        let mapping: any = [];        
        mapping[ModelChangeUpdateEvents.SEARCH_USER_SUCCESS] = (user: User) => { this.setUser(user); }
        super.registerStateChangeEvents(mapping);
  }

  ngOnInit() { 
    this.user = new User();
    this.hideError = true;
    this.userFound = false;
  }

  search(){
    let event = this.actionDispatcherService.generateEvent(ActionEvents.SEARCH_USER, {userId: this.userId});
    this.actionDispatcherService.dispatch(event);
  }

  setUser(user: User) {
    this.user = user;
  }

  parseUserLocation(location: string): any{
    let res = location.split('-');
    let result: Object = {
      location: res[0],
      building: res[1],
      floor: res[2],
      row: res[3],
      column: res[4]
    }
    return result;
  }
}