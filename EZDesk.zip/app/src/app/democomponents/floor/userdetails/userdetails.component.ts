import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";
import { Seat } from '../../../model/seat';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})

export class UserdetailsComponent extends BaseComponent implements OnInit {

  public userId: string;
  public firstName: string;
  public lastName: string;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
      super(stateRepresentationRendererService);
      
      let mapping: any = [];
      mapping[ModelChangeUpdateEvents.RETRIEVE_USER_SUCCESS] = (seat: Seat) => { this.renderUserRetrivalSuccess(seat); }

      super.registerStateChangeEvents(mapping);
  }

  ngOnInit() { }

	renderUserRetrivalSuccess(seat: Seat){
		this.userId = seat.userId;
		this.firstName = seat.firstName;
		this.lastName = seat.lastName;
	}
}
