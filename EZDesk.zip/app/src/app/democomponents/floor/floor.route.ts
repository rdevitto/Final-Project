import { RouterModule } from '@angular/router';
import { FloorComponent } from './floor.component';
import { SearchComponent } from './search.component';
import { CheckinComponent} from './checkin/checkin.component';
import { CheckoutComponent} from './checkout/checkout.component';
import { AuthGuard } from '../util/auth.guard';

export const floorRoutes=[
    { path: '', component: FloorComponent, canActivate: [AuthGuard] },
    { path: 'search', component: SearchComponent, canActivate: [AuthGuard]},
    { path: 'checkin/:location', component: CheckinComponent, canActivate: [AuthGuard]},
    { path: 'checkout', component: CheckoutComponent, canActivate: [AuthGuard]}
];

export const routing = RouterModule.forChild(floorRoutes);