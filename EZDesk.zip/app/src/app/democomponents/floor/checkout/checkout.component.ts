import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router, UrlTree, PRIMARY_OUTLET, UrlSegmentGroup, UrlSegment } from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  constructor(public activeRoute: ActivatedRoute, private http: Http, public router: Router) { }

  ngOnInit() {
  }

  release(){

    let userid = JSON.parse(localStorage.getItem('user')).userId;
    let location = JSON.parse(localStorage.getItem('user')).deskAssigned;
    let body = JSON.stringify({userid, location});
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({
      headers: headers,
      body : body
    });
    this.http.delete(environment.checkinURL, options).subscribe(response =>{
      if(response != null && response != undefined && response.status == 200) {
        alert("Checkout Success!");
        let user = JSON.parse(localStorage.getItem('user'));
        user.deskAssigned = '';
        localStorage.setItem('user', JSON.stringify(user));
        this.router.navigateByUrl('/floor'); 
      }else{
        alert("Checkout Failure!");
      }
    });

  }

  cancel(){
        this.router.navigateByUrl('/floor');
  }

}
