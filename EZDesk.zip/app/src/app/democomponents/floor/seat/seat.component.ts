import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";

@Component({
  selector: 'app-seat',
  templateUrl: './seat.component.html',
  styleUrls: ['./seat.component.css']
})
export class SeatComponent extends BaseComponent implements OnInit {

    public row : string;
    public column : string;
    public assignee : string;
    public availablity :  boolean = false;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
        
        let mapping: any = [];

        super.registerStateChangeEvents(mapping);
    }

	ngOnInit() {

	}

	retrieveUser(){
		console.log("Call Retrieve User: " + this.assignee);
		let event = this.actionDispatcherService.generateEvent(ActionEvents.RETRIEVE_USER, {user: this.assignee});
        this.actionDispatcherService.dispatch(event);
	}

}
