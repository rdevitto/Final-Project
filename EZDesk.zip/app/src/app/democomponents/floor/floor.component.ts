import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../events/action-events";
import { SearchComponent } from './search.component';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../../model/user';
import { UserdetailsComponent } from  './userdetails/userdetails.component';

@Component({
  selector: 'app-floor',
  templateUrl: './floor.component.html',
  styleUrls: ['./floor.component.css']
})

export class FloorComponent extends BaseComponent implements OnInit {

	@ViewChild('detailComponent') userdetailsComponent : UserdetailsComponent;

	//Location variables
	public locationOptions: string[];
	public defaultLocation: string = 'Select Location';
	public selectedLocation: string;

	public buildingOptions: string[]; 
	public defaultBuilding: string = 'Select Building';
	public selectedBuilding: string;
	
	public floorOptions: string[];
	public defaultFloor: string = 'Select Floor';
	public selectedFloor: string;

	public user: User;

	public userId: string;
	public row: string;
	public column: string;
	public lastname: string;

	public hideError: Boolean;
	public hideUserDetails: Boolean;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService, public router: Router) {
        super(stateRepresentationRendererService, );
        
        let mapping: any = [];        
		mapping[ModelChangeUpdateEvents.SEARCH_USER_SUCCESS] = (user: User) => { this.renderUI(user); }
		mapping[ModelChangeUpdateEvents.RETRIEVE_USER_NOT_SUCCESS] = (error: any) => { this.hideError = false; }
        super.registerStateChangeEvents(mapping);
    }

	ngOnInit() {
		this.hideError = true;
		this.hideUserDetails = false;
		this.locationOptions = ['ISU'];
		this.selectedLocation = this.defaultLocation;
		this.selectedBuilding = this.defaultBuilding;
		this.selectedFloor = this.defaultFloor;
		this.user = JSON.parse(localStorage.getItem('user'));
		//this.user.deskAssigned = 'ROSE-HIG-2-A-2';
		this.renderUI(this.user);
	}

	search(){
		this.hideError = true;
		this.userdetailsComponent.firstName = '';
		this.userdetailsComponent.lastName = '';
		this.userdetailsComponent.userId = '';
    	let event = this.actionDispatcherService.generateEvent(ActionEvents.SEARCH_USER, {lastname: this.lastname});
    	this.actionDispatcherService.dispatch(event);
  	}

	renderUI(user: User) {
		this.hideUserDetails = false;
		if(user.deskAssigned == 'NA') {
			this.hideUserDetails = true;
			this.selectedLocation = this.defaultLocation;
			this.selectedBuilding = this.defaultBuilding;
			this.selectedFloor = this.defaultFloor;
			return;
		}

		let deskDetails: any = this.parseDeskLocation(user.deskAssigned);
		if(deskDetails.location == "ISU") {
			this.selectedLocation = 'ISU';
		} else {
			this.selectedLocation = this.defaultLocation;
		}
	
		if(deskDetails.building == "STV") {
			this.selectedBuilding = "Stevenson";
			if(deskDetails.floor == "1")
				this.selectedFloor = "1st floor";
			else if(deskDetails.floor == "2")
				this.selectedFloor = "2nd floor";
			else 
				this.selectedFloor = this.defaultFloor;
		} else if (deskDetails.building == "MIL") {
			this.selectedBuilding = "Milner";
			if(deskDetails.floor == "3")
				this.selectedFloor = "3rd floor";
			else if(deskDetails.floor == "4")
				this.selectedFloor = "4th floor";
			else 
				this.selectedFloor = this.defaultFloor;
		} else {
			this.selectedBuilding = this.defaultBuilding;
		}
		this.row = deskDetails.row;
		this.column = deskDetails.column;

		let event = this.actionDispatcherService.generateEvent(ActionEvents.HIGHLIGHT_SEARCH_RESULT, {column: this.column, row: this.row, userId: user.userId});
    	this.actionDispatcherService.dispatch(event);
	}

	onLocationSelection($event) {
		console.log("select the specific location" + $event);
		if($event === 'ISU') {
			this.selectedBuilding = 'Select Building';
			this.selectedFloor = this.defaultFloor;
			this.buildingOptions = ['Stevenson', 'Milner', 'Old Union'];
			this.selectedLocation = $event;
		} else {
			this.selectedBuilding = 'Select Building ';
			this.selectedFloor = this.defaultFloor;
			this.buildingOptions = ['Pub II'];
			this.selectedLocation = $event;			
		}
	}

	onBuildingSelection($event) {
		if($event === 'Stevenson') {
			this.floorOptions = ['1st floor', '2nd floor'];
			this.selectedFloor = this.defaultFloor
		} else if($event === 'Milner') {
			this.floorOptions = ['3rd floor', '4th floor'];
			this.selectedFloor = this.defaultFloor
		} else {
			this.floorOptions = ['1st floor'];
			this.selectedFloor = this.defaultFloor
		}
	}

	onFloorSelection($event) {
		this.selectedFloor = $event;
		this.hideUserDetails = false;
		if(this.selectedFloor == '1st floor') {
			let event = this.actionDispatcherService.generateEvent(ActionEvents.LOAD_PLAN_A, {});
			this.actionDispatcherService.dispatch(event);
			return;
		} else if(this.selectedFloor == '3rd floor') {
			let event = this.actionDispatcherService.generateEvent(ActionEvents.LOAD_PLAN_B, {});
			this.actionDispatcherService.dispatch(event);
			return;
		} else {
			let event = this.actionDispatcherService.generateEvent(ActionEvents.LOAD_PLAN_B, {});
			this.actionDispatcherService.dispatch(event);
			// this.selectedFloor = '';
		}
	}

	private parseDeskLocation(location: string): any {
		let res = location.split('-');
		let result: Object = {
			location: res[0],
			building: res[1],
			floor: res[2],
			row: res[3],
			column: res[4]
		}
		return result;
	}

	signout() {
		this.router.navigateByUrl('/logoff');
	}
}
