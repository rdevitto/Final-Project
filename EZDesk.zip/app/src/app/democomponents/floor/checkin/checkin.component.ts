import { Component, OnInit,  } from '@angular/core';

import { ActivatedRoute, Router, UrlTree, PRIMARY_OUTLET, UrlSegmentGroup, UrlSegment } from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-checkin',
  templateUrl: './checkin.component.html',
  styleUrls: ['./checkin.component.css']
})
export class CheckinComponent implements OnInit {

  public location: string;

  constructor(public activeRoute: ActivatedRoute, private http: Http, public router: Router) { }

  ngOnInit() {
    this.activeRoute.params.subscribe(
      params => 
      {
        console.log(params.location);
        this.location = params.location;
        if(this.location === JSON.parse(localStorage.getItem('user')).deskAssigned){
        this.router.navigateByUrl('/floor/checkout');
      }
      }
    );
  }

  checkin(){

    let userid = JSON.parse(localStorage.getItem('user')).userId;
    let location = this.location;
    let body = JSON.stringify({userid, location});
    this.http.post(environment.checkinURL, body).subscribe(response =>{
      if(response != null && response != undefined && response.status == 200) {
        alert("Checkin Success!");
        let user = JSON.parse(localStorage.getItem('user'));
        user.deskAssigned = this.location;
        localStorage.setItem('user', JSON.stringify(user));
        this.router.navigateByUrl('/floor');
        
      }else{
        alert("Checkin Failure!");
      }

    });
  }

  cancel(){
    this.router.navigateByUrl('/floor');
  }


}
