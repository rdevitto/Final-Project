import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";
import { Seat } from '../../../model/seat';
import {SeatComponent} from '../seat/seat.component';

@Component({
  selector: 'app-plan-a',
  templateUrl: './plan-a.component.html',
  styleUrls: ['./plan-a.component.css']
})
export class PlanAComponent extends BaseComponent implements OnInit {


  @ViewChild('A1')
  A1: SeatComponent;
  @ViewChild('A2')
  A2: SeatComponent;
  @ViewChild('A3')
  A3: SeatComponent;
  @ViewChild('B1')
  B1: SeatComponent;
  @ViewChild('B2')
  B2: SeatComponent;
  @ViewChild('B3')
  B3: SeatComponent;
  @ViewChild('C1')
  C1: SeatComponent;
  @ViewChild('C2')
  C2: SeatComponent;
  @ViewChild('C3')
  C3: SeatComponent;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
        
        let mapping: any = [];        
		mapping[ModelChangeUpdateEvents.LOAD_PLAN_A_SUCCESS] = (seats: Array<any>) => { this.renderLoadSeat(seats); }
		mapping[ModelChangeUpdateEvents.HIGHLIGHT_SEARCH_RESULT_SUCCESS] = (data: any) => { this.highlight(data); }
        super.registerStateChangeEvents(mapping);
  }

  ngOnInit() { }

  highlight(data: any){
	console.log("highlight data:" + data.row + data.column);
	this.reset();
	if(( data.row +  data.column) === 'A1'){
		this.A1.availablity = true;
		this.A1.assignee = data.userId;
	}
	if(( data.row +  data.column) === 'A2'){
		this.A2.availablity = true;
		this.A2.assignee = data.userId;
	}
	if(( data.row +  data.column) === 'A3'){
		this.A3.availablity = true;
		this.A3.assignee = data.userId;
	}
	if(( data.row +  data.column) === 'B1'){
		this.B1.availablity = true;
		this.B1.assignee = data.userId;
	}
	if(( data.row +  data.column) === 'B2'){
		this.B2.availablity = true;
		this.B2.assignee = data.userId;
	}
	if(( data.row +  data.column) === 'B3'){
		this.B3.availablity = true;
		this.B3.assignee = data.userId;
	}
	if(( data.row +  data.column) === 'C1'){
		this.C1.availablity = true;
		this.C1.assignee = data.userId;
	}
	if(( data.row +  data.column) === 'C2'){
		this.C2.availablity = true;
		this.C2.assignee = data.userId;
	}
	if(( data.row +  data.column) === 'C3'){
		this.C3.availablity = true;
		this.C3.assignee = data.userId;
	}

  }

  reset(){
	  	this.A1.availablity = false;
	  	this.A2.availablity = false;
		this.A3.availablity = false;
		this.B1.availablity = false;
		this.B2.availablity = false;
		this.B3.availablity = false;
		this.C1.availablity = false;
		this.C2.availablity = false;
		this.C3.availablity = false;
  }

  renderLoadSeat(seats: Array<any>){
	  for(let i = 0; i < seats.length; i++){
		if(seats[i].desk === 'A-1'){
			this.A1.availablity = true;
			this.A1.assignee = seats[i].userid;
		}
		if(seats[i].desk === 'A-2'){
			this.A2.availablity = true;
			this.A2.assignee = seats[i].userid;
	  	}
		if(seats[i].desk === 'A-3'){
			 this.A3.availablity = true;
			 this.A3.assignee = seats[i].userid;				  
	  	}
		if(seats[i].desk === 'B-1'){
			this.B1.availablity = true;
			this.B1.assignee = seats[i].userid;
		}
		if(seats[i].desk === 'B-2'){
			this.B2.availablity = true;
			this.B2.assignee = seats[i].userid;
		}
		if(seats[i].desk === 'B-3'){
			this.B3.availablity = true;
			this.B3.assignee = seats[i].userid;
		}
		if(seats[i].desk === 'C-1'){
			this.C1.availablity = true;
			this.C1.assignee = seats[i].userid;
		}
		if(seats[i].desk === 'C-2'){
			this.C2.availablity = true;
			this.C2.assignee = seats[i].userid;
		}
		if(seats[i].desk === 'C-3'){
			this.C3.availablity = true;
			this.C3.assignee = seats[i].userid;
      	}
	  }
  }

}
