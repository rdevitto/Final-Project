import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plan-b',
  templateUrl: './plan-b.component.html',
  styleUrls: ['./plan-b.component.css']
})
export class PlanBComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
