import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanAComponent } from './plan-a.component';

describe('PlanAComponent', () => {
  let component: PlanAComponent;
  let fixture: ComponentFixture<PlanAComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanAComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanAComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
