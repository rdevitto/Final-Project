import { Component, OnInit, Input, Output, EventEmitter, HostBinding } from '@angular/core';

@Component({
  selector: 'sods-market-dropdown',
  templateUrl: './market-dropdown.component.html',
  styleUrls: ['./market-dropdown.component.css']
})
export class MarketDropdownComponent implements OnInit {

  isVisible: boolean = false;
  public selectedOptionObj: Object;
  @Input() selectedOption: string;
  @Input() options: any[];
  @Output() selectionDone = new EventEmitter();

  constructor() { }

  ngOnInit() {
    console.log(this.options)
    if (this.options) {
        this.selectedOptionObj = this.options.find(({divisionNumber}) => { return divisionNumber == this.selectedOption; })
    }
  }

  toggleDropDown(){
      this.isVisible = !this.isVisible;
  }

  select(option: any){;
    console.log(option);
      this.isVisible = !this.isVisible;
      this.selectedOptionObj = option;
      this.selectedOption = option.divisionNumber;  
      this.selectionDone.emit(this.selectedOption);
  }

}
