import { Component, OnInit, Input, Output, EventEmitter, HostBinding } from '@angular/core';

@Component({
  selector: 'sods-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {

  isVisible: boolean = false;
  @Input() selectedOption: string;
  @Input() options: string[];
  @Output() selectionDone = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  toggleDropDown(){
      this.isVisible = !this.isVisible;
  }

  select(option: string){;
      this.isVisible = !this.isVisible;
      this.selectedOption = option;  
      this.selectionDone.emit(this.selectedOption);
  }

}
