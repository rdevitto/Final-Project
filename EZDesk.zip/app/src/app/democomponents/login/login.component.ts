import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, Headers } from '@angular/http';
import { contentHeaders } from '../util/headers'; 
import { AuthenticationService } from '../../service/authentication.service'
import { User } from '../../model/user'

@Component({
  selector: 'login',
  templateUrl: './login.component.html',  
  styleUrls: ['./login.component.css'],
})

export class LoginComponent implements OnInit {
  public error: Boolean;
  returnUrl: string;

  constructor(public router: Router, public http: Http, private authService : AuthenticationService, private route: ActivatedRoute) { }

  ngOnInit() { 
    this.error = false;
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

    login(event, username, password) {
	  // this.authService.loginService(username, password).subscribe((response => {
    //   if(response.json() != null && response.json() != undefined && response.json().statusCode == 200) {
          
          var user = new User();

          user.deskAssigned = "ISU-STV-1-A-2";
          user.userId = "admin@ilstu.edu";
          user.firstName = "Mickey";
          user.lastName = "Mouse";
          let deskassigned = "ISU-STV-1-A-2";

          let expiration = new Date().getTime() + 60*60*1000;
          let record = {value: 'dummy token', timestamp: expiration}
          localStorage.setItem('user', JSON.stringify(user));
          localStorage.setItem('token', JSON.stringify(record));
          if(this.returnUrl === '/') {
            this.router.navigateByUrl('/floor');
          } else {
            this.router.navigateByUrl(this.returnUrl);
          }
        } 
        // else {
        //   this.error = true;
}