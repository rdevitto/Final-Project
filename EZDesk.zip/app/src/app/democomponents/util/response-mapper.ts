import { User } from '../../model/user';

export class ResponseMapper {

    static mapCustomer(data: any): User {
        let user: User = new User();
        user.id = data.id;
        user.firstName = data.firstName;
        user.LastName = data.lastName;
        //user.address1 = data.addr.addr1;
        //user.address2 = data.addr.addr2;
        user.seat = data.seat;
        return customer;
    }
}