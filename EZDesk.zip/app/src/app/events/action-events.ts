export class ActionEvents {

    //Header Event
    static RETRIEVE_USER_INFO = "retrieveUserInfo";
    //Load Plan A
    static LOAD_PLAN_A="loadPlanA";
    //Load Plan B
    static LOAD_PLAN_B="loadPlanB";
    //Retrieve User
    static RETRIEVE_USER='retrieveUser';
    //Search User
    static SEARCH_USER="searchUser";
    //Highlight Search Result
    static HIGHLIGHT_SEARCH_RESULT="highlight";
}
  
export class ModelChangeUpdateEvents {

    static LOAD_PLAN_A_SUCCESS="loadPlanASuccess";
    static LOAD_PLAN_B_SUCCESS="loadPlanBSuccess"
    static RETRIEVE_USER_SUCCESS="retrieveUserSuccess";
    static RETRIEVE_USER_NOT_SUCCESS="retrieveUserNotSuccess";
    static SEARCH_USER_SUCCESS="searchUserSuccess";
    static SEARCH_USER_FAILURE="searchUserFailure";
    static HIGHLIGHT_SEARCH_RESULT_SUCCESS='hightlightSuccess';

    //Header Model Change Events 
    static USER_INFO_FOUND = "userInfoFound";
    static USER_INFO_NOT_FOUND = "userInfoNotFound";
}