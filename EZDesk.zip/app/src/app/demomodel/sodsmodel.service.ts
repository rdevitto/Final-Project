import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Event } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from '../events/action-events';
import { contentHeaders } from '../democomponents/util/headers'; 
import { environment } from '../../environments/environment';
import { ActionSubscriber } from 'usf-sam';
import { Seat, SAMPLESEATA, SAMPLESEATB, SAMPLESEATC, SAMPLESEATD } from '../model/seat';
import { User, SAMPLEUSERA, SAMPLEUSERB } from '../model/user';
import { Header, SAMPLEHEADER } from '../model/header';

@Injectable()
export class SodsModelService {

    constructor(private http: Http){
        console.log("Initialize SODSModel Service");
    }

    @ActionSubscriber(ActionEvents.LOAD_PLAN_A)
    private loadPlanA() : Event<any> | Promise<Event<any>>{
        let resultingEvent: Event<any> = null;
        // let url: string = "http://localhost:8080";
        // return this.http.get(url).toPromise()                
        //     .then((response: Response) => {
        //         let userList: Array<any> = response.json().body;               
                return new Event<any>(ModelChangeUpdateEvents.LOAD_PLAN_A_SUCCESS, SAMPLEUSERA);                      
            // }, (err: Error) => {
            //     return new Event<any>('custNotFound', {});
            // }).catch(this.handleError);
    }
    
    @ActionSubscriber(ActionEvents.LOAD_PLAN_B)
    private loadPlanB() : Event<any> | Promise<Event<any>>{
        let resultingEvent: Event<any> = null;
        let seats : Seat[] = [];
        seats.push(SAMPLESEATC);
        seats.push(SAMPLESEATD);
        return new Event<any>(ModelChangeUpdateEvents.LOAD_PLAN_B_SUCCESS, seats); 
    }

    @ActionSubscriber(ActionEvents.RETRIEVE_USER)
    private retrieveUser(data: {user: string}) : Event<any> | Promise<Event<any>>{
        let resultingEvent: Event<any> = null;
        let url: string = environment.retrieveUserURL.concat(data.user);

        return this.http.get(url).toPromise()                
            .then((response: Response) => {
                let userDetail: any = response.json().body;   
                let seat = new Seat();
                seat.firstName = userDetail.firstname;
                seat.lastName = userDetail.lastname;
                seat.userId = userDetail.userid;
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_USER_SUCCESS, seat);                      
            }, (err: Error) => {
                return new Event<any>('custNotFound', {});
            }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.SEARCH_USER)
    private searchUser(data: {lastname: string}) : Event<any> | Promise<Event<any>>{
        let resultingEvent: Event<any> = null;
        let url: string = environment.searchURL.concat(data.lastname);

        return this.http.get(url).toPromise()                
            .then((response: Response) => {
                let userDetails: Array<any> = response.json().body;   
                let userDetail = userDetails[0];  
                let user = new User();
                user.userId = userDetail.userid;
                user.deskAssigned = userDetail.deskassigned;          
                return new Event<any>(ModelChangeUpdateEvents.SEARCH_USER_SUCCESS, user);                      
            }, (err: Error) => {
                return new Event<any>('custNotFound', {});
            }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.HIGHLIGHT_SEARCH_RESULT)
    private hightlight(data:{column: string, row:string, userId: string}) : Event<any> | Promise<Event<any>>{
        return new Event<any>(ModelChangeUpdateEvents.HIGHLIGHT_SEARCH_RESULT_SUCCESS, {'column': data.column, 'row': data.row, 'userId':data.userId});
    }

    private handleError (error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
        return Promise.reject(errMsg);
  }
}