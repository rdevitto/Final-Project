import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { UserComponent } from '../democomponents/common/user/user.component';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from '../democomponents/header/header.component';
import { DropdownComponent } from '../democomponents/common/dropdown/dropdown.component';
import { Collapse } from '../directive/collapse.component';
import { ModalModule } from 'ngx-modal';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ModalModule,
    RouterModule
  ],
  declarations: [
    UserComponent,
    HeaderComponent,
    DropdownComponent,
    Collapse
  ],
  exports:[
    CommonModule,
    FormsModule,
    UserComponent,
    HeaderComponent,
    DropdownComponent,
    Collapse
  ]
})

export class SharedModule { }