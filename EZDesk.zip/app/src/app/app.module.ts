import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';

//Import the service here
import { ActionDispatcherService, ModelPresenterService, EventTypeRegistryService, StateRepresentationRendererService } from 'usf-sam';

//Login Component
import { LoginComponent } from './democomponents/login/login.component';
import { LogOffComponent } from './democomponents/login/logoff.component';

//Header Component
import { HeaderComponent } from './democomponents/header/header.component'

//Routing
import { appRoutingProviders, routing } from './app.routes';
import { AuthGuard } from './democomponents/util/auth.guard';

//Register the SODSModelService
import { SodsModelService } from './demomodel/sodsmodel.service';
import { AuthenticationService } from './service/authentication.service';
import { FilenotfoundComponent } from './democomponents/login/filenotfound.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LogOffComponent,
    FilenotfoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing
  ],
  providers: [
    ActionDispatcherService, 
    ModelPresenterService, 
    SodsModelService,
    EventTypeRegistryService,
    StateRepresentationRendererService,
    AuthenticationService,
    AuthGuard],
  bootstrap: [AppComponent]
})

export class AppModule { }