export class User {
    userId: string;
    password: string;
    firstName: string;
    lastName: string;
    deskAssigned: string;
    openWorkArea: string;
    deskAssignDate: string;
}

export const SAMPLEUSERA: User = {
    userId: 'rdevitt@ilstu.edu',
    password: '123',
    firstName: 'Randall',
    lastName: 'DeVitto',
    deskAssigned: 'ISU-STV-1-A-4',
    openWorkArea: '',
    deskAssignDate: ''
}

export const SAMPLEUSERB: User = {
    userId: 'dcramer@ilstu.edu',
    password: '123',
    firstName: 'Dylan',
    lastName: 'Cramer',
    deskAssigned: 'ISU-MIL-3-B-2',
    openWorkArea: '',
    deskAssignDate: ''
}