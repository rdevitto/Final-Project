export class Seat {
    userId: any;
    firstName: string;
    lastName: string;
    row: string;
    column: string;
}

export const SAMPLESEATA: Seat = {
    userId: 'rdevitt@ilstu.edu',
    firstName: 'Randall',
    lastName: 'DeVitto',
    row: "A",
    column: "4"
}

export const SAMPLESEATB: Seat = {
    userId: 'dcramer@ilstu.edu',
    firstName: 'Dylan',
    lastName: 'Cramer',
    row: "B",
    column: "2"
}

export const SAMPLESEATC: Seat = {
    userId: 'AO86026',
    firstName: 'Mickey',
    lastName: 'Mouse',
    row: "C",
    column: "1"
}

export const SAMPLESEATD: Seat = {
    userId: 'temp@gmail.com',
    firstName: 'Jon',
    lastName: 'Smith',
    row: "B",
    column: "3"
}