// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  envName: 'dev',
  loginURL: 'https://1lumvssqo4.execute-api.us-east-2.amazonaws.com/prod/user',
  tokenParserURL: 'https://awldrsodas01.cloud.usfood.com/sods-jwt-parser-api/v1/sods/info',
  // tokenParserURL: 'http://localhost:8080/sods-jwt-parser-api/v1/sods/info',
  generateReqIdURL: 'https://awldrsodas01.cloud.usfood.com/sods-requisitionid-generation-api/v1/sods/requisitionid',
  customerInquiryURL: 'https://awldrsodas01.cloud.usfood.com/sods-cust-inquiry-api/v1/sods/customer?',
  retrieveUserURL:  "https://1lumvssqo4.execute-api.us-east-2.amazonaws.com/prod/user/",
  ROSEMONT_HIG_2_URL: "https://3z5b2a98vi.execute-api.us-east-2.amazonaws.com/prod/location/ROSEMONT-HIG-2",
  checkinURL: "https://3z5b2a98vi.execute-api.us-east-2.amazonaws.com/prod/location",
  searchURL: "https://1lumvssqo4.execute-api.us-east-2.amazonaws.com/prod/user/search/"

};
