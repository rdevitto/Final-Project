import { MySODSPage } from './app.po';

describe('my-sods App', () => {
  let page: MySODSPage;

  beforeEach(() => {
    page = new MySODSPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
